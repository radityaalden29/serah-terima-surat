@extends('layouts.app')

@section('content')

<div class="row justify-content-center">

    <div class="col-lg-8">

        <div class="d-flex justify-content-between align-items-center mb-4">

            <div>

                <h2 class="fw-bold mb-1">
                    Edit Surat
                </h2>

                <p class="text-muted mb-0">
                    Ubah data serah terima surat.
                </p>

            </div>

            <a href="{{ route('surat.index') }}" class="btn btn-secondary">
                <i class="bi bi-arrow-left"></i>
                Kembali
            </a>

        </div>

        <div class="card shadow border-0">

            <div class="card-body">

                <form action="{{ route('surat.update',$surat->id) }}"
                      method="POST"
                      enctype="multipart/form-data">

                    @csrf
                    @method('PUT')

                    {{-- No Agenda --}}
                    <div class="mb-3">

                        <label class="form-label">
                            No Agenda
                        </label>

                        <input
                            type="text"
                            name="no_agenda"
                            class="form-control @error('no_agenda') is-invalid @enderror"
                            value="{{ old('no_agenda',$surat->no_agenda) }}">

                        @error('no_agenda')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror

                    </div>

                    {{-- Jenis --}}
                    <div class="mb-3">

                        <label class="form-label">
                            Jenis Surat
                        </label>

                        <select
                            name="jenis"
                            class="form-select @error('jenis') is-invalid @enderror">

                            <option value="">-- Pilih Jenis --</option>

                            <option value="Surat Masuk"
                                {{ old('jenis',$surat->jenis)=='Surat Masuk'?'selected':'' }}>
                                Surat Masuk
                            </option>

                            <option value="Surat Keluar"
                                {{ old('jenis',$surat->jenis)=='Surat Keluar'?'selected':'' }}>
                                Surat Keluar
                            </option>

                        </select>

                        @error('jenis')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror

                    </div>

                    {{-- Pengirim --}}
                    <div class="mb-3">

                        <label class="form-label">
                            Pengirim
                        </label>

                        <input
                            type="text"
                            name="pengirim"
                            class="form-control @error('pengirim') is-invalid @enderror"
                            value="{{ old('pengirim',$surat->pengirim) }}">

                        @error('pengirim')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror

                    </div>

                    {{-- Penerima --}}
                    <div class="mb-3">

                        <label class="form-label">
                            Penerima
                        </label>

                        <input
                            type="text"
                            name="penerima"
                            class="form-control @error('penerima') is-invalid @enderror"
                            value="{{ old('penerima',$surat->penerima) }}">

                        @error('penerima')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror

                    </div>

                    {{-- Perihal --}}
                    <div class="mb-3">

                        <label class="form-label">
                            Perihal
                        </label>

                        <textarea
                            name="perihal"
                            rows="4"
                            class="form-control @error('perihal') is-invalid @enderror">{{ old('perihal',$surat->perihal) }}</textarea>

                        @error('perihal')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror

                    </div>

                    {{-- Tanggal --}}
                    <div class="mb-3">

                        <label class="form-label">
                            Tanggal
                        </label>

                        <input
                            type="date"
                            name="tanggal"
                            class="form-control @error('tanggal') is-invalid @enderror"
                            value="{{ old('tanggal',$surat->tanggal) }}">

                        @error('tanggal')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror

                    </div>

                    {{-- Status --}}
                    <div class="mb-3">

                        <label class="form-label">
                            Status
                        </label>

                        <select
                            name="status"
                            class="form-select @error('status') is-invalid @enderror">

                            <option value="Menunggu"
                                {{ old('status',$surat->status)=='Menunggu'?'selected':'' }}>
                                Menunggu
                            </option>

                            <option value="Diterima"
                                {{ old('status',$surat->status)=='Diterima'?'selected':'' }}>
                                Diterima
                            </option>

                            <option value="Dikirim"
                                {{ old('status',$surat->status)=='Dikirim'?'selected':'' }}>
                                Dikirim
                            </option>

                        </select>

                        @error('status')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror

                    </div>

                    {{-- Lampiran --}}
                    <div class="mb-4">

                        <label class="form-label">
                            Lampiran (PDF)
                        </label>

                        <input
                            type="file"
                            name="lampiran"
                            class="form-control @error('lampiran') is-invalid @enderror"
                            accept=".pdf">

                        @error('lampiran')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror

                        @if($surat->lampiran)

                            <small class="text-success d-block mt-2">

                                Lampiran saat ini :

                                <a href="{{ asset('storage/'.$surat->lampiran) }}"
                                   target="_blank">

                                    Lihat PDF

                                </a>

                            </small>

                        @endif

                    </div>

                    <div class="d-flex justify-content-end">

                        <button class="btn btn-primary">

                            <i class="bi bi-check-circle"></i>

                            Update Surat

                        </button>

                    </div>

                </form>

            </div>

        </div>

    </div>

</div>

@endsection
