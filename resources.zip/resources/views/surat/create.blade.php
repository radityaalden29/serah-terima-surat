@extends('layouts.app')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>
        <h2 class="fw-bold">Tambah Surat</h2>
        <p class="text-muted">Isi data serah terima surat.</p>
    </div>

    <a href="{{ route('surat.index') }}" class="btn btn-secondary">
        Kembali
    </a>

</div>

<div class="card shadow border-0">

    <div class="card-body">

        <form action="{{ route('surat.store') }}"
              method="POST"
              enctype="multipart/form-data">

            @csrf

            <div class="row">

                <div class="col-md-6 mb-3">

                    <label>No Agenda</label>

                    <input
                        type="text"
                        name="no_agenda"
                        class="form-control"
                        required>

                </div>

                <div class="col-md-6 mb-3">

                    <label>Jenis Surat</label>

                    <select
                        name="jenis"
                        class="form-select">

                        <option>Surat Masuk</option>
                        <option>Surat Keluar</option>

                    </select>

                </div>

                <div class="col-md-6 mb-3">

                    <label>Pengirim</label>

                    <input
                        type="text"
                        name="pengirim"
                        class="form-control">

                </div>

                <div class="col-md-6 mb-3">

                    <label>Penerima</label>

                    <input
                        type="text"
                        name="penerima"
                        class="form-control">

                </div>

                <div class="col-12 mb-3">

                    <label>Perihal</label>

                    <textarea
                        name="perihal"
                        class="form-control"
                        rows="3"></textarea>

                </div>

                <div class="col-md-6 mb-3">

                    <label>Tanggal</label>

                    <input
                        type="date"
                        name="tanggal"
                        class="form-control">

                </div>

                <div class="col-md-6 mb-3">

                    <label>Status</label>

                    <select
                        name="status"
                        class="form-select">

                        <option>Menunggu</option>
                        <option>Diterima</option>
                        <option>Dikirim</option>

                    </select>

                </div>


                <div class="col-12 mb-3">

                    <label>Lampiran PDF</label>

                    <input
                        type="file"
                        name="lampiran"
                        class="form-control"
                        accept=".pdf">

                </div>

            </div>

            <button class="btn btn-primary">

                Simpan Surat

            </button>

        </form>

    </div>

</div>

@endsection
