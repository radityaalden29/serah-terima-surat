@extends('layouts.app')

@section('content')

@if(session('success'))
<div class="alert alert-success">
    {{ session('success') }}
</div>
@endif

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>
        <h2 class="fw-bold mb-1">
            Data Surat
        </h2>

        <p class="text-muted mb-0">
            Daftar seluruh data serah terima surat.
        </p>
    </div>

    <a href="{{ route('surat.create') }}" class="btn btn-add">
    <i class="bi bi-plus-circle-fill"></i>
    <span>Tambah Surat</span>
</a>

</div>

<form action="{{ route('surat.index') }}" method="GET" class="mb-4">

    <div class="input-group">

        <span class="input-group-text">
            <i class="bi bi-search"></i>
        </span>

        <input
            type="text"
            class="form-control"
            name="search"
            placeholder="Cari nomor agenda, pengirim atau penerima..."
            value="{{ request('search') }}">

        <button class="btn btn-primary">
            Cari
        </button>

    </div>

</form>

<div class="card shadow-sm border-0">

    <div class="card-body">

        <div class="table-responsive">

            <table class="table table-hover align-middle">

                <thead class="table-light">

                    <tr>
                        <th>No</th>
                        <th>No Agenda</th>
                        <th>Jenis</th>
                        <th>Pengirim</th>
                        <th>Penerima</th>
                        <th>Tanggal</th>
                        <th>Status</th>
                       <th width="220" class="text-center">Aksi</th>
                    </tr>

                </thead>

                <tbody>

                @forelse($surats as $surat)

                    <tr>

                        <td>{{ $surats->firstItem() + $loop->index }}</td>

                        <td>{{ $surat->no_agenda }}</td>

                        <td>{{ $surat->jenis }}</td>

                        <td>{{ $surat->pengirim }}</td>

                        <td>{{ $surat->penerima }}</td>

                        <td>{{ $surat->tanggal }}</td>

                        <td>

                            @if($surat->status == 'Menunggu')

                                <span class="badge bg-warning">
                                    Menunggu
                                </span>

                            @elseif($surat->status == 'Diterima')

                                <span class="badge bg-success">
                                    Diterima
                                </span>

                            @else

                                <span class="badge bg-primary">
                                    Dikirim
                                </span>

                            @endif

                        </td>

                      <td class="text-center">

    <div class="action-group">

        <a href="{{ route('surat.show',$surat->id) }}"
           class="btn-action view">

            <i class="bi bi-eye"></i>

            <span>Lihat</span>

        </a>

        <a href="{{ route('surat.edit',$surat->id) }}"
           class="btn-action edit">

            <i class="bi bi-pencil"></i>

            <span>Edit</span>

        </a>

        <form action="{{ route('surat.destroy',$surat->id) }}"
              method="POST"
              class="delete-form">

            @csrf
            @method('DELETE')

            <button class="btn-action delete">

                <i class="bi bi-trash"></i>

                <span>Hapus</span>

            </button>

        </form>

    </div>

</td>

                    </tr>

                @empty

                    <tr>

                        <td colspan="8" class="text-center">
                            Belum ada data surat.
                        </td>

                    </tr>

                @endforelse

                </tbody>

            </table>

        </div>

        <div class="mt-3">

            {{ $surats->links() }}

        </div>

    </div>

</div>

@push('scripts')
<script>

document.querySelectorAll('.delete-form').forEach(form => {

    form.addEventListener('submit', function(e){

        e.preventDefault();

        Swal.fire({

            title: 'Hapus Surat?',
            text: 'Data yang dihapus tidak dapat dikembalikan!',
            icon: 'warning',

            showCancelButton: true,

            confirmButtonText: 'Ya, Hapus',
            cancelButtonText: 'Batal',

            confirmButtonColor: '#6f42c1',
            cancelButtonColor: '#d33'

        }).then((result)=>{

            if(result.isConfirmed){

                form.submit();

            }

        });

    });

});

</script>
@endpush

@endsection
