@extends('layouts.app')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>

        <h2 class="fw-bold mb-1">
            Detail Surat
        </h2>

        <p class="text-muted">
            Informasi lengkap data surat.
        </p>

    </div>

    <div>

        <a href="{{ route('surat.edit',$surat->id) }}"
           class="btn btn-warning">

            <i class="bi bi-pencil-square"></i>

            Edit

        </a>

        <a href="{{ route('surat.index') }}"
           class="btn btn-secondary">

            <i class="bi bi-arrow-left"></i>

            Kembali

        </a>

    </div>

</div>

<div class="card shadow border-0">

    <div class="card-header text-white"
         style="background:#6f42c1;">

        <h5 class="mb-0">

            Data Surat

        </h5>

    </div>

    <div class="card-body">

        <div class="row mb-3">

            <div class="col-md-3 fw-bold">
                No Agenda
            </div>

            <div class="col-md-9">
                {{ $surat->no_agenda }}
            </div>

        </div>

        <hr>

        <div class="row mb-3">

            <div class="col-md-3 fw-bold">
                Jenis Surat
            </div>

            <div class="col-md-9">
                {{ $surat->jenis }}
            </div>

        </div>

        <hr>

        <div class="row mb-3">

            <div class="col-md-3 fw-bold">
                Pengirim
            </div>

            <div class="col-md-9">
                {{ $surat->pengirim }}
            </div>

        </div>

        <hr>

        <div class="row mb-3">

            <div class="col-md-3 fw-bold">
                Penerima
            </div>

            <div class="col-md-9">
                {{ $surat->penerima }}
            </div>

        </div>

        <hr>

        <div class="row mb-3">

            <div class="col-md-3 fw-bold">
                Perihal
            </div>

            <div class="col-md-9">
                {{ $surat->perihal }}
            </div>

        </div>

        <hr>

        <div class="row mb-3">

            <div class="col-md-3 fw-bold">
                Tanggal
            </div>

            <div class="col-md-9">
                {{ \Carbon\Carbon::parse($surat->tanggal)->translatedFormat('d F Y') }}
            </div>

        </div>

        <hr>

        <div class="row mb-3">

            <div class="col-md-3 fw-bold">
                Status
            </div>

            <div class="col-md-9">

                @if($surat->status=="Menunggu")

                    <span class="badge bg-warning">
                        Menunggu
                    </span>

                @elseif($surat->status=="Diterima")

                    <span class="badge bg-success">
                        Diterima
                    </span>

                @else

                    <span class="badge bg-primary">
                        Dikirim
                    </span>

                @endif

            </div>

        </div>

        <hr>

        <div class="row">

            <div class="col-md-3 fw-bold">
                Lampiran
            </div>

            <div class="col-md-9">

                @if($surat->lampiran)

                    <a href="{{ asset('storage/'.$surat->lampiran) }}"
                       target="_blank"
                       class="btn btn-danger">

                        <i class="bi bi-file-earmark-pdf-fill"></i>

                        Lihat Lampiran PDF

                    </a>

                @else

                    <span class="text-muted">

                        Tidak ada lampiran.

                    </span>

                @endif

            </div>

        </div>

    </div>

</div>

@endsection
