@extends('layouts.app')

@section('content')

<div class="card shadow">

    <div class="card-header bg-white">

        <h3 class="fw-bold mb-0">
            Tentang SISTERA
        </h3>

    </div>

    <div class="card-body">

        <h5>SISTERA</h5>

        <p>
            SISTERA (Sistem Informasi Serah Terima Surat) merupakan Website yang digunakan untuk mengelola proses serah terima
            surat masuk maupun surat keluar secara digital.
        </p>

        <hr>

        <h5>Fitur Sistem</h5>

        <ul>
            <li>Dashboard</li>
            <li>Tambah Surat</li>
            <li>Data Surat</li>
            <li>Edit Surat</li>
            <li>Hapus Surat</li>
            <li>Laporan</li>
            <li>Statistik Surat</li>
        </ul>

        <hr>

        <h5>Teknologi</h5>

        <table class="table table-bordered">

            <tr>
                <th>Framework</th>
                <td>Laravel 12</td>
            </tr>

            <tr>
                <th>CSS</th>
                <td>Bootstrap 5</td>
            </tr>

            <tr>
                <th>Database</th>
                <td>SQLite</td>
            </tr>

            <tr>
                <th>Chart</th>
                <td>Chart.js</td>
            </tr>

        </table>

    </div>

</div>

@endsection
