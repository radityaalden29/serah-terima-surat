<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SISTERA | Sistem Informasi Serah Terima Surat</title>

    @vite([
        'resources/css/app.css',
        'resources/js/app.js'
    ])
</head>

<body>

<div class="wrapper">

    <!-- Sidebar -->
    <aside class="sidebar">

      <div class="logo">

    <img src="{{ asset('images/logo-sistera.png') }}"
         alt="Logo SISTERA"
         class="logo-image">

</div>

        <ul class="menu">

            <li>

                <a href="{{ route('dashboard') }}"
                   class="{{ request()->routeIs('dashboard') ? 'active' : '' }}">

                    <i class="bi bi-grid-fill"></i>

                    Dashboard

                </a>

            </li>

            <li>

                <a href="{{ route('surat.index') }}"
                   class="{{ request()->routeIs('surat.*') ? 'active' : '' }}">

                    <i class="bi bi-folder-fill"></i>

                    Data Surat

                </a>

            </li>

            <li>

                <a href="{{ route('surat.create') }}">

                    <i class="bi bi-plus-circle-fill"></i>

                    Tambah Surat

                </a>

            </li>

            <li>

                <a href="{{ route('laporan') }}">

                    <i class="bi bi-bar-chart-fill"></i>

                    Laporan

                </a>

            </li>

           <li>

    <a href="{{ route('tentang') }}"
       class="{{ request()->routeIs('tentang') ? 'active' : '' }}">

        <i class="bi bi-info-circle-fill"></i>

        Tentang

    </a>

</li>

        </ul>

    </aside>

    <!-- Main -->
    <main class="main-content">

        <!-- Topbar -->
        <header class="topbar">

            <div>

                <h4 class="mb-0">
                    Sistem Informasi Serah Terima Surat
                </h4>

                <small class="text-muted">
                    Universitas Pakuan
                </small>

            </div>

            <div class="topbar-right">

              <div class="date-box d-flex align-items-center gap-2">

    <i class="bi bi-calendar-event"></i>

    <span id="tanggal"></span>

    <span>|</span>

    <i class="bi bi-clock"></i>

    <span id="jam"></span>

</div>

            </div>

        </header>

        <section class="content">

            @yield('content')

            <footer class="text-center mt-5 mb-3 text-muted">

    © {{ date('Y') }} SISTERA - Sistem Informasi Serah Terima Surat

</footer>

        </section>

    </main>

</div>

@if(session('success'))

<script>
Swal.fire({
    icon:'success',
    title:'Berhasil',
    text:'{{ session('success') }}',
    timer:2000,
    showConfirmButton:false
});
</script>

@endif

@stack('scripts')

<script>
document.addEventListener("DOMContentLoaded", function () {

    function updateClock() {

        const now = new Date();

        const tanggal = now.toLocaleDateString('id-ID', {
            weekday: 'long',
            day: '2-digit',
            month: 'long',
            year: 'numeric'
        });

        const jam = now.toLocaleTimeString('id-ID', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });

        document.getElementById('tanggal').textContent = tanggal;
        document.getElementById('jam').textContent = jam;
    }

    updateClock();
    setInterval(updateClock, 1000);

});
</script>

</body>
</html>
