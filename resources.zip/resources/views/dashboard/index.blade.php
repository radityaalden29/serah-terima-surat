@extends('layouts.app')

@section('content')

<div class="dashboard-header mb-5">

    <div>
        <h1 class="fw-bold mb-2">
            Dashboard
        </h1>

        <p class="text-muted fs-5">
            Selamat datang di <strong>SISTERA</strong>.
            Kelola seluruh proses serah terima surat secara cepat,
            aman dan terdokumentasi.
        </p>
    </div>

    <div>

     <a href="{{ route('surat.create') }}" class="btn btn-tambah shadow">
    <i class="bi bi-plus-circle"></i>
    <span>Tambah Surat</span>
</a>

    </div>

</div>

<div class="row g-4 mb-5">

    <!-- Total -->

    <div class="col-lg-3 col-md-6">

        <div class="dashboard-card card-total">

            <div class="card-icon">
                <i class="bi bi-envelope-paper"></i>
            </div>

            <small>Total Surat</small>

            <h2>{{ $totalSurat }}</h2>

            <span class="card-info">
                Semua data surat
            </span>

        </div>

    </div>

    <!-- Masuk -->

    <div class="col-lg-3 col-md-6">

        <div class="dashboard-card card-masuk">

            <div class="card-icon">
                <i class="bi bi-download"></i>
            </div>

            <small>Surat Masuk</small>

            <h2>{{ $suratMasuk }}</h2>

            <span class="card-info">
                Surat diterima
            </span>

        </div>

    </div>

    <!-- Keluar -->

    <div class="col-lg-3 col-md-6">

        <div class="dashboard-card card-keluar">

            <div class="card-icon">
                <i class="bi bi-upload"></i>
            </div>

            <small>Surat Keluar</small>

            <h2>{{ $suratKeluar }}</h2>

            <span class="card-info">
                Surat dikirim
            </span>

        </div>

    </div>

    <!-- Menunggu -->

    <div class="col-lg-3 col-md-6">

        <div class="dashboard-card card-menunggu">

            <div class="card-icon">
                <i class="bi bi-hourglass-split"></i>
            </div>

            <small>Menunggu</small>

            <h2>{{ $menunggu }}</h2>

            <span class="card-info">
                Perlu diproses
            </span>

        </div>

    </div>

</div>


<!-- CHART -->

<div class="row g-4">

   <div class="col-lg-8">

    <div class="card shadow border-0 rounded-4">

        <div class="card-body">

            <h5 class="fw-bold mb-3">
                Statistik Surat
            </h5>

            <div style="height:320px;">
                <canvas id="chartSurat"></canvas>
            </div>

        </div>

    </div>

</div>

    <div class="col-lg-4">

        <div class="card shadow border-0 rounded-4 h-100">

            <div class="card-body">

                <h5 class="fw-bold mb-4">

                    Ringkasan

                </h5>

                <div class="mb-4">

                    <small>Total Surat</small>

                    <h3>{{ $totalSurat }}</h3>

                </div>

                <div class="mb-4">

                    <small>Surat Masuk</small>

                    <h3>{{ $suratMasuk }}</h3>

                </div>

                <div class="mb-4">

                    <small>Surat Keluar</small>

                    <h3>{{ $suratKeluar }}</h3>

                </div>

                <div>

                    <small>Menunggu</small>

                    <h3>{{ $menunggu }}</h3>

                </div>

            </div>

        </div>

    </div>

</div>

<!-- TABEL -->
<div class="card shadow border-0 rounded-4 mt-4">

    <div class="card-body">

        <h5 class="fw-bold mb-4">
            Aktivitas Terbaru
        </h5>

        <div class="table-responsive">

            <table class="table table-hover align-middle">

                <thead>
                    <tr>
                        <th>No</th>
                        <th>No Agenda</th>
                        <th>Jenis</th>
                        <th>Pengirim</th>
                        <th>Status</th>
                    </tr>
                </thead>

                <tbody>

                    @forelse($surats as $surat)

                        <tr>
                            <td>{{ $loop->iteration }}</td>
                            <td>{{ $surat->no_agenda }}</td>
                            <td>{{ $surat->jenis }}</td>
                            <td>{{ $surat->pengirim }}</td>
                            <td>
                                @if($surat->status == 'Menunggu')
                                    <span class="badge bg-warning text-dark">
                                        <i class="bi bi-hourglass-split me-1"></i>
                                        Menunggu
                                    </span>

                                @elseif($surat->status == 'Diterima')
                                    <span class="badge bg-success">
                                        <i class="bi bi-check-circle me-1"></i>
                                        Diterima
                                    </span>

                                @else
                                    <span class="badge bg-primary">
                                        <i class="bi bi-send me-1"></i>
                                        Dikirim
                                    </span>
                                @endif
                            </td>
                        </tr>

                    @empty

                        <tr>
                            <td colspan="5" class="text-center text-muted py-4">
                                Belum ada data surat.
                            </td>
                        </tr>

                    @endforelse

                </tbody>

            </table>

        </div>

    </div>

</div>

@push('scripts')

<script>

document.addEventListener('DOMContentLoaded', function () {

    const canvas = document.getElementById('chartSurat');

    if (!canvas) return;

    new window.Chart(canvas, {

        type: 'doughnut',

        data: {
            labels: [
                'Surat Masuk',
                'Surat Keluar',
                'Menunggu'
            ],

            datasets: [{
                data: [
                    {{ $suratMasuk }},
                    {{ $suratKeluar }},
                    {{ $menunggu }}
                ],

                backgroundColor: [
                    '#6f42c1',
                    '#9b5de5',
                    '#6c757d'
                ],

                borderWidth: 0
            }]
        },

        options: {
            responsive: true,
            maintainAspectRatio: false,

            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }

    });

});

</script>

@endpush

@endsection
